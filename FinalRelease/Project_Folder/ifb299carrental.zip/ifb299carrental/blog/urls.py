from django.conf.urls import url
from blog import views
# Create your views here.
urlpatterns = [
    url(r'^$', views.archive),
]
