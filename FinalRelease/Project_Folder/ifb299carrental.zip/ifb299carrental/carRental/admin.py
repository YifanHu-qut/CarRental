from django.contrib import admin
from carRental import models
# Register your models here.
admin.site.register(models.Order)
