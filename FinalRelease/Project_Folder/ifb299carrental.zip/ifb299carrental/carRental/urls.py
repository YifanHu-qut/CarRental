from django.conf.urls import url
from carRental import views
urlpatterns = [
    url(r'^$', views.homepage),
    url(r'customeroverview', views.customeroverview),
    url(r'about', views.about, name = 'about'),
    url(r'userlogin', views.userlogin, name = 'userlogin'),
    url(r'homepage', views.homepage, name = 'homepage'),
    url(r'signup', views.signup, name = 'signup'),
    #url(r'order', views.orderInformtaion),
    url(r'orderoverview', views.orderoverview, name='orderoverview'),
    url(r'caroverview', views.caroverview, name='caroverview'),
    url(r'freebrowsing', views.freebrowsing),
    url(r'storerecord', views.storerecord),
    url(r'recommend', views.recommend),
    url(r'^logout/$', views.user_logout, name='logout'),
    url(r'monthlyoutcome', views.monthlyoutcome,name = 'monthlyoutcome'),
    url(r'staffinformation', views.staffinformation),
    url(r'contactus', views.contactus),
]
