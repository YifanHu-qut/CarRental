//********Homepage
//let the picture slide
function picture_MEL(){    
		var oBox=document.getElementById('box_MEL');    
		var oUl=oBox.children[0];    
		var aLi=oUl.children;    
			   
		oUl.innerHTML+=oUl.innerHTML;    
		oUl.style.width=aLi.length*aLi[0].offsetWidth+'px';    
			 
		setInterval(function(){ 
			var l=oUl.offsetLeft-10;
			if(l<=-oUl.offsetWidth/2){    
				l=0;    
			}    
			oUl.style.left=l+'px';    
		},130);    
}

//let the picture slide
function picture_BNE(){    
		var oBox=document.getElementById('box_BNE');    
		var oUl=oBox.children[0];    
		var aLi=oUl.children;    
			   
		oUl.innerHTML+=oUl.innerHTML;    
		oUl.style.width=aLi.length*aLi[0].offsetWidth+'px';    
			 
		setInterval(function(){ 
			var l=oUl.offsetLeft-10;
			if(l<=-oUl.offsetWidth/2){    
				l=0;    
			}    
			oUl.style.left=l+'px';    
		},130);    
}

//For testing only
function show(){
	alert("hello");
}

//**********Signup page
//check if name is valid
function checkName(){
	var regex=/^[A-Za-z]+\s[A-Za-z]+$/;
	var name = document.getElementById("name").value;
	var judge = true;
	if( name.length==0 || !regex.test(name) ){
		document.getElementById("nameError").style.visibility = "visible";
		judge = false;
	}else{
		document.getElementById("nameError").style.visibility = "hidden";
		judge = true;
	}
	return judge;
}

function checkUserName(){
	var regex=/^[A-Za-z0-9]+$/;
	var name = document.getElementById("username").value;
	var judge = true;
	if( name.length==0 || !regex.test(name) ){
		document.getElementById("UsernameError").style.visibility = "visible";
		judge = false;
	}else{
		document.getElementById("UsernameError").style.visibility = "hidden";
		judge = true;
	}
	return judge;
}



//check if role is selected
function checkRoleButton(){
	var judge = true;
	if (document.getElementById("staff").checked ||document.getElementById("customer").checked){
		document.getElementById("RoleButtonError").style.visibility = "hidden";
		judge = true;
	}else{
		document.getElementById("RoleButtonError").style.visibility = "visible";
		judge = false;
	}
	return judge;
}

//check if gender is selected
function checkRadioButton(){
	var judge = true;
	if (document.getElementById("Female").checked ||document.getElementById("Male").checked){
		document.getElementById("RadioBUttonError").style.visibility = "hidden";
		judge = true;
	}else{
		document.getElementById("RadioBUttonError").style.visibility = "visible";
		judge = false;
	}
	return judge;
}

//check if DOB is valid 
function checkDOB(){
	var regex=/^\d{2}\/\d{2}\/\d{4}$/;
	var dob = document.getElementById("DOB").value;
	var judge = true;
	if( dob.length==0 || !regex.test(dob) ){
		document.getElementById("BirthError").style.visibility = "visible";
		judge = false;
	}else{
		document.getElementById("BirthError").style.visibility = "hidden";
		judge = true;
	}
	return judge;
}

//check if occupation is inputted
function checkOccupation(){
	var regex=/^[A-Za-z]+$/;
	var occupation = document.getElementById("occupation").value;
	var judge = true;
	if( occupation.length==0 || !regex.test(occupation) ){
		document.getElementById("occupationError").style.visibility = "visible";
		judge = false;
	}else{
		document.getElementById("occupationError").style.visibility = "hidden";
		judge = true;
	}
	return judge;
}

//check if phone number is valid
function checkPhone(){
	var regex=/^[0-9]+$/;
	var phoneNumber = document.getElementById("phoneNumber").value;
	var judge = true;
	if( phoneNumber.length==0 || !regex.test(phoneNumber) ){
		document.getElementById("phoneError").style.visibility = "visible";
		judge = false;
	}else{
		document.getElementById("phoneError").style.visibility = "hidden";
		judge = true;
	}
	return judge;
}

//check if address is valid
function checkAddress(){
	var regex=/^[0-9]+[A-Za-z ]+$/;
	var streetAddress = document.getElementById("streetAddress").value;
	var judge = true;
	if( streetAddress.length==0 || !regex.test(streetAddress) ){
		document.getElementById("addressError").style.visibility = "visible";
		judge = false;
	}else{
		document.getElementById("addressError").style.visibility = "hidden";
		judge = true;
	}
	return judge;
}

//check if password is valid
function checkPassword(){
	var userpassward = document.getElementById("password").value;
	var judge = true;
	var format =  /[a-zA-Z](?=.*?[1-9].*?)[a-zA-Z1-9]+|[1-9](?=.*?[a-zA-Z].*?)[a-zA-Z1-9]+/g;  
	if( userpassward.length <= 8 || !format.test(userpassward)){
		document.getElementById("passwordError").style.visibility = "visible";
		judge = false;
	}else{
		document.getElementById("passwordError").style.visibility = "hidden";
		judge = true;
	}
	return judge;
}

//check if confirming password is valid
function confirmUserPw(){
	var confirmUserPw = document.getElementById("Cpassword").value;
	var previousPw = document.getElementById("password").value
	var judge = true;
	if( confirmUserPw != previousPw){
		document.getElementById("confirmError").style.visibility = "visible";
		judge = false;
	}else{
		document.getElementById("confirmError").style.visibility = "hidden";
		judge = true;
	}
	return judge;	
}

//after submitting, the correct information is kept
function validate(){	
	var successName = checkName();
	var successUsername = checkUserName();
	var successRole = checkRoleButton();
	var successRadio = checkRadioButton();
	var successDOB = checkDOB();
	var successOccupation = checkOccupation();
	var successPhone = checkPhone();
	var successAddress =checkAddress();
	var successPassword =checkPassword();
	var successCPassword =confirmUserPw();
	if(successName == false || successRadio == false || successDOB == false
	   || successOccupation == false|| successPhone == false || successAddress == false
	    || successPassword == false ||successCPassword== false ||successRole== false || successUsername == false){	
		return false;
	}
}

function checkOrderID(){
	var regex=/^[0-9]+$/;
	var orderid = document.getElementById("orderID").value;
	var judge = true;
	if( orderid.length==0 || !regex.test(orderid) ){
		document.getElementById("orderIdError").style.visibility = "visible";
		judge = false;
	}else{
		document.getElementById("orderIdError").style.visibility = "hidden";
		document.getElementById("insertButton").disabled = false;
		judge = true;
	}
	return judge;
}

function checkCreateDate(){
	var regex=/^[0-9]+$/;
	var orderid = document.getElementById("orderCreateDate").value;
	var judge = true;
	if( orderid.length==0 || !regex.test(orderid) ){
		document.getElementById("orderIdError").style.visibility = "visible";
		judge = false;
	}else{
		document.getElementById("orderIdError").style.visibility = "hidden";
		judge = true;
	}
	return judge;
}

function checkPickDate(){
	var regex=/^[0-9]+$/;
	var orderid = document.getElementById("orderPickupDate").value;
	var judge = true;
	if( orderid.length==0 || !regex.test(orderid) ){
		document.getElementById("orderIdError").style.visibility = "visible";
		judge = false;
	}else{
		document.getElementById("orderIdError").style.visibility = "hidden";
		judge = true;
	}
	return judge;
}

function checkPickStore(){
	var regex=/^[0-9]+$/;
	var orderid = document.getElementById("orderPickupStore").value;
	var judge = true;
	if( orderid.length==0 || !regex.test(orderid) ){
		document.getElementById("orderIdError").style.visibility = "visible";
		judge = false;
	}else{
		document.getElementById("orderIdError").style.visibility = "hidden";
		judge = true;
	}
	return judge;
}

function checkReturnDate(){
	var regex=/^[0-9]+$/;
	var orderid = document.getElementById("orderReturnDate").value;
	var judge = true;
	if( orderid.length==0 || !regex.test(orderid) ){
		document.getElementById("orderIdError").style.visibility = "visible";
		judge = false;
	}else{
		document.getElementById("orderIdError").style.visibility = "hidden";
		judge = true;
	}
	return judge;
}

function checkReturnStore(){
	var regex=/^[0-9]+$/;
	var orderid = document.getElementById(orderReturnStore).value;
	var judge = true;
	if( orderid.length==0 || !regex.test(orderid) ){
		document.getElementById("orderIdError").style.visibility = "visible";
		judge = false;
	}else{
		document.getElementById("orderIdError").style.visibility = "hidden";
		judge = true;
	}
	return judge;
}

function checkCustomerID(){
	var regex=/^[0-9]+$/;
	var orderid = document.getElementById(customerID).value;
	var judge = true;
	if( orderid.length==0 || !regex.test(orderid) ){
		document.getElementById("orderIdError").style.visibility = "visible";
		judge = false;
	}else{
		document.getElementById("orderIdError").style.visibility = "hidden";
		judge = true;
	}
	return judge;
}

function checkCustomerName(){
	var regex=/^[A-Za-z]+\s[A-Za-z]+$/;
	var name = document.getElementById("customerName").value;
	var judge = true;
	if( name.length==0 || !regex.test(name) ){
		document.getElementById("NameError").style.visibility = "visible";
		judge = false;
	}else{
		document.getElementById("NameError").style.visibility = "hidden";
		judge = true;
	}
	return judge;
}

function checkCarID(){
	var regex=/^[0-9]+$/;
	var orderid = document.getElementById(CarID).value;
	var judge = true;
	if( orderid.length==0 || !regex.test(orderid) ){
		document.getElementById("orderIdError").style.visibility = "visible";
		judge = false;
	}else{
		document.getElementById("orderIdError").style.visibility = "hidden";
		judge = true;
	}
	return judge;
}

function test(){
	alert();
}

